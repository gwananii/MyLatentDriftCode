# Replication package: Latent Boundary Drift

Run the notebook parts 0-11 in order (or `python ldrift_pipeline.py`).
Data snapshots go in `data/clean` as `<ASSET>_clean.csv` or `<TICKER>.csv`.

## Software

- python: 3.12.7
- platform: Windows-11-10.0.22631-SP0
- numpy: 1.26.4
- pandas: 2.2.2
- scipy: 1.13.1
- matplotlib: 3.9.2
- yfinance: 1.6.0
- numba: 0.68.1

## Manuscript object -> output

| Manuscript | Output (tables/ unless stated) | Produced by |
| --- | --- | --- |
| Table 1 | table1_gamma_grid | Part 7 |
| Section 3.3 GJR values | table_gjr_examples | Part 7 |
| Section 3.3 grid (min gap, 12.3%) | table_phase_grid | Part 7 |
| Table 2 | table2_full_samples | Part 4 |
| Table 3 | table3_drift95 | Part 4 |
| Table 4 | table4_threshold_profile | Part 4 |
| Table B1 | tableB1_regimes (+ table_hill_all, table_drift_all) | Part 4 analyse_sample |
| Section 5.2 out-of-sample | table_oos_drift | Part 5 |
| Tables 6 and 7 | table6_7_var_backtests | Part 5 (Tables 6 and 7: same forecasts; FHS and GARCH-t added) |
| Table 8 | table8_es_backtests | Part 5 (with simulation p-values for Z1 and Z2) |
| Table 9 | table9_single_split | Part 5 single_split |
| Section 5.6 | table_robust_* | see part headers |
| Rolling refits, failed fits, xi >= 1 | table_refit_log, table_refit_summary | Part 5 |
| Size of drift tests (new, editor 1.4) | table_size_sim | Part 8a (A3: size evidence) |
| Table C1 | tableC1_profiles, tableC1_notes | Part 8b |
| Table 5 | table5_hill_sim | Part 8c (percentiles over few paths are descriptive) |
| Table D1 | tableD1 | Part 8d |
| Tables E1, E2 | tableE1_egarch_ratios, tableE2_egarch_tail_index | Part 8e |
| Appendix F / Figure F1 | tableF_threshold_diagnostics | Part 9 |
| Figures 2-7, F1 | figures/fig*.png|pdf | see part headers |
| Exceptions for abstract/conclusions | table_exceptions | Part 10 (editor 3.9) |
| Editor 2.1: FHS and GARCH-t benchmarks | table6_7_var_backtests, table8_es_backtests (models FHS, GARCH-t) | Part 5 (Tables 6 and 7: same forecasts; FHS and GARCH-t added) |
| Z1/Z2 simulation p-values | table8_es_backtests (Z1_sim_p, Z2_sim_p) | Part 5 (with simulation p-values for Z1 and Z2) |
| Editor 2.2: threshold/window sensitivity | table_sensitivity_backtests, table_sensitivity_summary | Part 8B (editor 2.2) |
| Editor 2.3: Proposition 3 illustration | table_prop3_illustration, table_prop3_rates, table_prop3_montecarlo, figures/fig_prop3_illustration | Part 8B (editor 2.3) |
| Table 10, Section 5.7 (asymmetric filters) | table_asym_fits, table_asym_drift, table_asym_backtests, table_asym_refits, table_asym_constraint_check | Part 8C (full-sample fits; EA must be < 1) |
| Data download log and checksums | table_download_log, table_data_checksums | see part headers |
| Changed numbers vs submission | table_paper_vs_run | Part 10 |